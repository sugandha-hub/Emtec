package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.main.Employee;
import com.example.demo.repo.EmployeeRepo;
import com.example.demo.service.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService as;
	
	@GetMapping("/employees")
	public List<Employee> get() {
		return as.getEmployees();
	}
	
	@GetMapping("/employees/{id}")
	public Optional<Employee> getById(@PathVariable("id") int id) {
		return as.getEmployeeById(id);
	}
	
	@PostMapping("/employees")
	public Employee post(@RequestBody Employee employee) {
		 return as.insertEmployee(employee);
	}
	
	@SuppressWarnings("deprecation")
	@DeleteMapping("/employees/{id}")
	public String delete(@PathVariable("id") int id) {

		return as.deleteEmployee(id);
	}
	
	
	@PutMapping("/employees")
	public Employee put(@RequestBody Employee employee) {
		return as.updateEmployee(employee);
	}
	
	@GetMapping("/employees/name={name}")
		public Optional<Employee> getByName(@PathVariable("name") String name){
			return as.getEmployeesByName(name);
			
		}
	
	@GetMapping("/employees/tech={tech}")
	public Optional<Employee> getByTech(@PathVariable("tech") String tech){
		return as.getEmployeesByTech(tech);
		
	}
	
//	@PutMapping("/employees/{name}/{tech}/{address}")
//
//	public String putByName(@PathVariable("name") String name,@PathVariable("tech") String tech,@PathVariable("address") String address)
//	{
//		return as.updateEmployeesByName(tech,address,name);
//	}
//	
	@GetMapping("/employees/get/id/name")

	public List<String> getOnlyIdAndName(){
		return as.getEmployeeIdAndName();
	}
	
	@GetMapping("/employees/get/name")

	public List<String> getOnlyNames(){
		return as.getEmployeeNames();
	}
	
	
	@PutMapping("/employees/{name}/{tech}/{address}")
	public int updateByName(@PathVariable("name") String name,@PathVariable("tech") String tech,@PathVariable("address") String address) {
		System.out.println("mappped....");
		
		return as.updateEmployeesByName(tech,address,name);
	}
	
	@DeleteMapping("/employees")
	public int dropTable() {
		return as.dropTable();
	}
	
	@PostMapping("/employees/alter")
	public int alterTable() {
		return as.alterTable();
	}
	
	@PutMapping("/employees/rename")
	public int renameTable() {
		return as.renameTable();
	}
	
	@PostMapping("/employees/create")
	public int createTable() {
		return as.createTable();
	}
	

	

	

}
















