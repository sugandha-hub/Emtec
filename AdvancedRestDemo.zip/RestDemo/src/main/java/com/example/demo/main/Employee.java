package com.example.demo.main;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Component
public class Employee {

	// accessing application properties data

	@Id

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	@Column(name="id")
	private int eid;
	
	@Column(name="name")
	private String ename; 
	
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", etech=" + etech + ", eaddress=" + eaddress + "]";
	}

	@Column(name="tech")
	private String etech;
	
	@Column(name="address")
	private String eaddress;

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEtech() {
		return etech;
	}

	public void setEtech(String etech) {
		this.etech = etech;
	}

	public String getEaddress() {
		return eaddress;
	}

	public void setEaddress(String eaddress) {
		this.eaddress = eaddress;
	}

	

	

//	@Value("${name}")
//
//	private String appname;
//
//	public void showApplicationPropertiesData() {
//		System.out.println("Name=" + appname);
//
//	}

}
