package com.example.demo.repo;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.example.demo.main.Employee;


public interface EmployeeRepo extends JpaRepository<Employee,Integer>{
	
	Optional<Employee> findByEname(String name);
	Optional<Employee> findByEtech(String tech);
	
//	@Query(value="update Employee set tech=t,address=a where name=n",nativeQuery=true)
//	 Employee updateEmployeesByName(@Param("t") String tech,@Param("a") String address,@Param("n") String name);
//	 
	@Query(value="SELECT name from Employee",nativeQuery=true)
	List<String> getEmployeeNames();
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value="UPDATE employee set tech=:t,address=:a where name=:n",nativeQuery=true)
	int updateEmployeesByName(@Param("t") String tech,@Param("a") String address,@Param("n") String name);
	

	@Query(value="SELECT id,name from Employee",nativeQuery=true)
	List<String> getEmployeeIdAndName();
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value="DROP table emp",nativeQuery=true)
	int dropTable();
	
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value="ALTER TABLE emp ADD hobby varchar(40)",nativeQuery=true)
	int alterTable();
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value="ALTER TABLE emp rename to student",nativeQuery=true)
	int renameTable();
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value="CREATE table if not exists emp(name varchar(50))",nativeQuery=true)
	int createTable();
	
	
	
	
}
 