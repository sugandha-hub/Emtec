package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.main.Employee;
import com.example.demo.repo.EmployeeRepo;
import com.example.demo.repo.JdbcRepo;

@Service
public class EmployeeService {
	

	@Autowired
	EmployeeRepo repo;
	
	

	public List<Employee> getEmployees() {
		return repo.findAll();
	}
	

	public Optional<Employee> getEmployeeById(int id) {
		return repo.findById(id);
	}
	

	public Employee insertEmployee(Employee employee) {
		 repo.save(employee);
		 return employee;
	}
	
	
	public String deleteEmployee(int id) {
		Employee a=repo.getOne(id);
		repo.delete(a);
		return "deleted";
	}
	
	
	
	public Employee updateEmployee(Employee employee) {
		 repo.save(employee);
		 return employee;
	}
	
	public Optional<Employee> getEmployeesByName(String name){
		return repo.findByEname(name);
	}
	
	public Optional<Employee> getEmployeesByTech(String tech){
		return repo.findByEtech(tech);
	}
	
//	public String updateEmployeesByName(String tech,String address,String name) {
//	    repo.updateEmployeesByName(tech, address, name);
//		return "updated";
//	}
	
	public List<String> getEmployeeNames(){
	   return repo.getEmployeeNames();
		
	}
	
	public List<String> getEmployeeIdAndName(){
		   return repo.getEmployeeIdAndName();
			
		}
	
	public int updateEmployeesByName(String name,String tech,String address) {
		 repo.updateEmployeesByName(name,tech,address);
		 return 1;
	}
	
	public int dropTable() {
		repo.dropTable();
		return 1;
	}
	
	public int alterTable() {
		repo.alterTable();
		return 1;
	}
	
	public int renameTable() {
		repo.renameTable();
		return 1;
	}
	
	public int createTable() {
		repo.createTable();
		return 1;
	}
	
	


}
