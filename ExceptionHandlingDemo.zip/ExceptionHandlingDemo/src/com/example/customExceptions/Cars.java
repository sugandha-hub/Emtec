package com.example.customExceptions;

public class Cars{
	
	public void mercedes() throws SpeedNotAllowedException{
		int speed=80;
		if(speed>70) {
			throw new SpeedNotAllowedException();
		}
		
		
		
	}
	
	public void ford() {
		String color="white";
		if(color=="white") {
			throw new ColorNotAllowedException();
		}
	}

}




