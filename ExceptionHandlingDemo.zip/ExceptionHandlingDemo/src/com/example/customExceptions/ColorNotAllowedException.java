package com.example.customExceptions;

public class ColorNotAllowedException extends RuntimeException {
	ColorNotAllowedException(){
		super("White color isn't allowed");
	}

}
