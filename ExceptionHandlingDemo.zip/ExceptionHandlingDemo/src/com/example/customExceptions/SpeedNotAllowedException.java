package com.example.customExceptions;

public class SpeedNotAllowedException extends Exception {
	SpeedNotAllowedException(){
		super("Speed shouldn't be more than 70");
		
	}
	

}
