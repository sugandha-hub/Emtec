package com.example.exceptionPropagation;

public class CarPropagation {
	
	public void mercedes() {
		ford();
		
	}
	
	public void ford() {
		lamborghini();
		
	}
	public void lamborghini() {
		int a=100;
		int data=a/0;
	}

}
