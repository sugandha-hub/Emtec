package com.example.predefinedExceptions;

import com.example.customExceptions.Cars;
import com.example.exceptionPropagation.CarPropagation;

public class Student extends Exception{
	
	public static void main(String args[]) {
		Student s1=new Student();
		try {
			s1.data();
			s1.calculate();
			
		}
		catch(Exception e) {
			System.out.println("Predefined Exceptions Caught");
		}
		
		Cars car=new Cars();
		try {
			car.mercedes();
			car.ford();
			
		}
		catch(Exception e) {
			System.out.println("Custom Exceptions Caught");
		}
		
		CarPropagation prop=new CarPropagation();
		try {
			prop.mercedes();
			
		}
		catch(Exception e) {
			System.out.println("Exception Propagation Exception Caught");
		}
		
		
	
		
	}
	
	void data() throws ClassNotFoundException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		
	}
	
	void calculate() {
		int marks=100;
		int val=marks/0;
		
		
	}

}

