import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class APIapp {
	
	public static void main(String args[]) {
		
		SpringApplication.run(APIapp.class, args);
		
	}

}
