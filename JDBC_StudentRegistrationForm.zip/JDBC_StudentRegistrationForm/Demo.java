import java.sql.*;
import javax.swing.*;
import java.awt.event.*;

public class Demo extends JFrame {

    public static void main(String args[]) {

        JFrame f = new JFrame("Student Registration Form");
        f.setSize(700, 700);
        f.setLayout(null);
        f.setVisible(true);
        JLabel heading = new JLabel("Student Registration Form");
        heading.setBounds(200, 100, 200, 15);

        JLabel name = new JLabel("Name");
        name.setBounds(100, 150, 100, 15);
        JTextField nametf = new JTextField();
        nametf.setBounds(400, 150, 100, 15);

        JLabel city = new JLabel("City");
        city.setBounds(100, 200, 100, 15);
        JTextField citytf = new JTextField();
        citytf.setBounds(400, 200, 100, 15);

        JLabel contact = new JLabel("Contact");
        contact.setBounds(100, 250, 100, 15);
        JTextField contacttf = new JTextField();
        contacttf.setBounds(400, 250, 100, 15);

        JLabel degree = new JLabel("Degree");
        degree.setBounds(100, 300, 100, 15);
        String arr1[] = { "BTech", "BCS", "BCA", "BBA", "LLM" };
        JComboBox degreetf = new JComboBox(arr1);
        degreetf.setBounds(400, 300, 100, 15);

        JLabel branch = new JLabel("Branch");
        branch.setBounds(100, 350, 100, 15);
        String arr2[] = { "IT", "CSE", "ETC", "AUTO", "NA" };
        JComboBox branchtf = new JComboBox(arr2);
        branchtf.setBounds(400, 350, 100, 15);

        JLabel clas = new JLabel("Class");
        clas.setBounds(100, 400, 100, 15);
        String arr3[] = { "First Year", "Second Year", "Third Year", "Fourth Year" };
        JComboBox clastf = new JComboBox(arr3);
        clastf.setBounds(400, 400, 100, 15);

        JButton submit = new JButton("Submit");
        submit.setBounds(200, 500, 100, 15);

        f.add(heading);
        f.add(name);
        f.add(city);
        f.add(contact);
        f.add(degree);
        f.add(branch);
        f.add(clas);
        f.add(nametf);
        f.add(citytf);
        f.add(contacttf);
        f.add(degreetf);
        f.add(branchtf);
        f.add(clastf);
        f.add(submit);

        submit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent a) {
                Connection con = null;
                Statement stmt;

                String StudName = nametf.getText().toString();
                String StudCity = citytf.getText().toString();
                String StudContact = contacttf.getText();
                String StudDegree = degreetf.getSelectedItem().toString();
                String StudBranch = branchtf.getSelectedItem().toString();
                String StudClas = clastf.getSelectedItem().toString();

              
                    try {

                        Class.forName("com.mysql.jdbc.Driver");
                        con = DriverManager.getConnection("jdbc:mysql://localhost:3307/rit", "root", "");
                        stmt = con.createStatement();
                        stmt.executeUpdate("insert into student values('" + StudName + "','" + StudCity + "','"
                                + StudContact + "','" + StudDegree + "','" + StudBranch + "','" + StudClas + "')");
                        JOptionPane.showMessageDialog(f, "Submitted Successfully");

                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            con.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                }

        });
}}