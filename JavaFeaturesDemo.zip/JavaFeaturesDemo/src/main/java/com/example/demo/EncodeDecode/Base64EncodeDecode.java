package com.example.demo.EncodeDecode;

import java.util.Base64;

import org.springframework.stereotype.Component;

@Component
public class Base64EncodeDecode {
	
	public void encodeDecode() {
		//getting encoder
		Base64.Encoder encoder=Base64.getEncoder();
		
		//encoding
		String str=encoder.encodeToString("Sugandha Dhanawade".getBytes());
		System.out.println("Encrypted string="+str);
		
		
		//getting decoder
		Base64.Decoder decoder=Base64.getDecoder();
		String dstr=new String(decoder.decode(str));
		System.out.println("Decrypted string="+dstr);
		
	}

}
