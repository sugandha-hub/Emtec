package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.EncodeDecode.Base64EncodeDecode;
import com.example.demo.StringJoiner.StringJoinerExample;
import com.example.demo.defaultMethod.DefaultMethod;
import com.example.demo.lymdaFunction.LymdaFunction;
import com.example.demo.methodReference.MethodReference;
import com.example.demo.nashorn.NashornExample;
import com.example.demo.optionalClass.OptionalClass;
import com.example.demo.parallelsort.ParallelSort;
import com.example.demo.stream.Stream;
import com.example.demo.typeinference.TypeInference;

@SpringBootApplication
public class JavaFeaturesDemoApplication {

	public static void main(String[] args) throws Exception  {
		
		ConfigurableApplicationContext context=SpringApplication.run(JavaFeaturesDemoApplication.class, args);
//		context.getBean(LymdaFunction.class);
//		LymdaFunction obj=new LymdaFunction();
//		obj.lymdaMethod();
		
//		context.getBean(MethodReference.class);
//		MethodReference obj=new MethodReference();
//		obj.main();
		
//		context.getBean(Stream.class);
//		Stream obj=new Stream();
//		obj.streamMethod();
		
//		context.getBean(Base64EncodeDecode.class);
//		Base64EncodeDecode obj=new Base64EncodeDecode();
//		obj.encodeDecode();
		
//		context.getBean(DefaultMethod.class);
//		DefaultMethod obj=new DefaultMethod();
//		obj.defaultMethod();
		
//		context.getBean(StringJoinerExample.class);
//		StringJoinerExample obj=new StringJoinerExample();
//		obj.stringJoiner();
		
//		context.getBean(OptionalClass.class);
//		OptionalClass obj=new OptionalClass();
//		obj.NonOptionalClass2();
		
//		context.getBean(NashornExample.class);
//		NashornExample obj=new NashornExample();
//		obj.nashorn();
		
//		context.getBean(ParallelSort.class);
//		ParallelSort obj=new ParallelSort();
//		obj.parallelSort();
		
		context.getBean(TypeInference.class);
		TypeInference obj=new TypeInference();
		obj.typeInference();
	}

}
