package com.example.demo.StringJoiner;

import java.util.StringJoiner;

import org.springframework.stereotype.Component;

@Component
public class StringJoinerExample {
	
	public void stringJoiner() {
		StringJoiner sj=new StringJoiner(",","[","]");
		sj.add("Sugandha");
		sj.add("Rutuja");
		sj.add("Janaki");
		
		System.out.println(sj);
		
	}
	

}
