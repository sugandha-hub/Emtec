package com.example.demo.defaultMethod;

import org.springframework.stereotype.Component;


interface Demo{
	default void say() {
		System.out.println("I am non abstract method by interface");
		
	}
	void sayMore();
}


@Component
public class DefaultMethod implements Demo{
	public void defaultMethod() {
		Demo d=new DefaultMethod();
		d.say();
		d.sayMore();
		
	}

	@Override
	public void sayMore() {
		System.out.println("I am abstract method by interface");
		// TODO Auto-generated method stub
		
	}

}
