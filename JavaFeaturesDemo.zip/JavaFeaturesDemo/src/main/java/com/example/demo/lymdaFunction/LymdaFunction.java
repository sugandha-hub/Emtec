package com.example.demo.lymdaFunction;

import org.springframework.stereotype.Component;

@FunctionalInterface
interface Interface{
	void Method();
	
}

@FunctionalInterface
interface Interface2{
	void Method(String name);
	
}


@Component
public class LymdaFunction {
	public void lymdaMethod() {
		
		//non-parameterized interface method
		Interface li=()->{
			System.out.println("I am the method of functional interface");
		};
		li.Method();
		
		//parameterized interface method
		Interface2 li2=(String name)->{
			
			System.out.println("Good morning, "+name);
		};
		
		String n="Sugandha";
		li2.Method(n);
		
	}
	

}
