package com.example.demo.methodReference;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@FunctionalInterface
interface Interface{
	void method();
}



@Component
@Scope(value="prototype")
public class MethodReference {
	
	public static void staticMethod() {
		System.out.println("I am static method");
	}
	
	public void instanceMethod() {
		System.out.println("I am instance method");
	}
	
	public MethodReference(){
		System.out.println("I am constructor");
	}
	public void main() {
		//static method reference
		Interface i=MethodReference::staticMethod;
		i.method();

		
		//instance method reference
		Interface i2=new MethodReference()::instanceMethod;
		i2.method();
		
		//constructor reference
		Interface i3= MethodReference::new;
		i3.method();
		
	}

	

}
