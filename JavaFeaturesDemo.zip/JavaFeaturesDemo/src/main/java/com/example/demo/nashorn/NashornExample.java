package com.example.demo.nashorn;

import java.io.FileReader;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import org.springframework.stereotype.Component;

@Component
public class NashornExample {
	
	public void nashorn() throws Exception {
		ScriptEngine se=new ScriptEngineManager().getEngineByName("Nashorn");
		se.eval("print('Hello Nashorn');");
	}

}
