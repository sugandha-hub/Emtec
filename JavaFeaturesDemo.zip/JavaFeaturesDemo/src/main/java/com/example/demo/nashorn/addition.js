a=10
b=20
print("addition=",(a+b))