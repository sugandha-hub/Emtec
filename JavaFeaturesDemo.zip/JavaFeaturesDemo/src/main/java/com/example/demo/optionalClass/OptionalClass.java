package com.example.demo.optionalClass;

import java.util.Optional;

import org.springframework.stereotype.Component;

@Component
public class OptionalClass {
	
	public void optionalClass1() {
		String name=null;
		Optional<String> check=Optional.ofNullable(name);
		if(check.isPresent()) {
			
			System.out.print(1);
		}
		else {
			
			System.out.print(0);
		}
	}
	
	public void NonOptionalClass2() {
		String name=null;

		if(name.contains(null)) {
			
			System.out.print(0);
		}
		else {
			
			System.out.print(1);
		}
	}

}
