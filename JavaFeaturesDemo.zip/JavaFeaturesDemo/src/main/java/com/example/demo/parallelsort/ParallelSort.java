package com.example.demo.parallelsort;

import java.util.Arrays;

import org.springframework.stereotype.Component;

@Component
public class ParallelSort {
	
	public void parallelSort() {
		int[] array= {20,30,10,50,40};
		
		System.out.println("Array before sorting...");
		for(int i=0;i<array.length;i++) {
			
			System.out.print(array[i]+" ");
		}
		
		Arrays.parallelSort(array);
		System.out.println("\nArray after sorting...");
		for(int i=0;i<array.length;i++) {
			
			System.out.print(array[i]+" ");
		}
	}

}
