package com.example.demo.stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.stereotype.Component;

@Component
public class Stream {
	
	public void streamMethod() {
		 List<Integer> list = Arrays.asList(3, 6, 9, 12, 15);
		  
		list.stream().map(data->data*1).forEach(System.out::println);
		
		list.stream().collect(Collectors.toList()).forEach(System.out::println);
		
		list.stream().filter(data->data>9).forEach(System.out::println);
	
	
	}

}
