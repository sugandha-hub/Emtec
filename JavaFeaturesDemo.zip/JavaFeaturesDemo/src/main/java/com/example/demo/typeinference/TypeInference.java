package com.example.demo.typeinference;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class TypeInference {
	
	public void typeInference() {
		//old method
		List<String> list1=new ArrayList<String>();
		list1.add("Sugandha");
		list1.add("Rutuja");
		list1.add("Janaki");
		
		list1.forEach(data->System.out.println(data));
		
		//new method
		List<String> list2=new ArrayList<>();
		list2.add("Sugandha");
		list2.add("Rutuja");
		list2.add("Janaki");
		
		list2.forEach(data->System.out.println(data));
		
	}

}
