package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.main.Allien;
import com.example.demo.main.AllienRepo;
import com.example.demo.service.AllienService;

@RestController
public class AllienController {
	
	@Autowired
	AllienService as;
	
	@PostMapping("/alliens/create")
	public int create() {
	return as.createTable();
	}
	
//	
	@PutMapping("/alliens/{aid}/{aname}/{atech}/{aquote}")
	public int update(@PathVariable("aid") int aid,@PathVariable("aname") String aname,@PathVariable("atech") String atech, @PathVariable("aquote") String aquote) {
		return as.updateAllien(aid, aname, atech,aquote);
		
	}
//	Allien
//	
	@PostMapping("/alliens/{aid}/{aname}/{atech}/{aquote}")
	public int insert(@PathVariable("aid") int aid,@PathVariable("aname") String aname,@PathVariable("atech") String atech, @PathVariable("aquote") String aquote) {
		return as.insertAllien(aid, aname, atech, aquote);
		
	}
//	
//	
//	
	@DeleteMapping("/alliens/{aid}")
	public int delete(@PathVariable("aid") int aid) {
		return as.deleteAllien(aid);
		
	}
	
	@GetMapping("/alliens")
	public List<String> get(){
		return as.getAlliens();
	}
	
	@PutMapping("/alliens/{aid}/quote={aquote}")
	public int updateQuoteById(@PathVariable("aid") int aid,@PathVariable("aquote") String aquote) {
		return as.updateQuoteById(aid, aquote);
	}
	
	@PutMapping("/alliens/{aname}/quote:{aquote}")
	public int updateQuoteByName(@PathVariable("aname") String aname,@PathVariable("aquote") String aquote) {
		return as.updateQuoteByName(aname, aquote);
	}
	
	
//	
//	
//	@PutMapping("/alliens")
//	public Allien put(@RequestBody Allien allien) {
//		return as.updateAlliens(allien);
//		
//	}
//
//	
//	//custom functions here
//	
//	@GetMapping("/alliens/name={aname}")
//	public Optional<Allien> getByName(@PathVariable("aname") String aname) {
//		return as.getAlliensByName(aname);
//	}
//
//	
//	
//	@GetMapping("/alliens/tech:{atech}")
//	public Optional<Allien> getByTech(@PathVariable("atech") String atech) {
//		return as.getAlliensByTech(atech);
//		
//	}
	
	

}
















