package com.example.demo.repo;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.main.Allien;


@Repository
public class JdbcRepo {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	
	public int createTable() {
		int update=this.jdbcTemplate.update("create table if not exists Allien(aid int primary key, aname varchar(50), atech varchar(50), aquote varchar(100))");
		return update;
	}
	
	public int insertAllien(int aid,String aname,String atech, String aquote) {
		int update=this.jdbcTemplate.update("insert into Allien(aid,aname,atech,aquote)values(?,?,?,?)",
				new Object[] {aid,aname,atech,aquote});
		System.out.print("User created");
		return update;
	}
	
	public int updateAllien(int aid,String aname,String atech,String aquote) {
		int update=this.jdbcTemplate.update("update Allien set aname=?,atech=?,aquote=? where aid=?",
				new Object[] {aname,atech,aquote,aid});
		System.out.println("updated.........");
		return update;
	}
	
	public int deleteAllien(int aid) {
		int update=this.jdbcTemplate.update("delete from Allien where aid=?",aid);
		return update;
	}
	
	public List<String> getAlliens(){
		List<String> alliens=new ArrayList<>();
		alliens.addAll(jdbcTemplate.queryForList("select aname from Allien", String.class));
		return alliens;
	}
		
	
	//updating quote based on id
	
	public int updateQuoteById(int aid,String aquote) {
		int update=this.jdbcTemplate.update("update Allien set aquote=? where aid=?",
				new Object[] {aquote,aid});
	
		return update;
	}
	
	//updating quote based on name
	public int updateQuoteByName(String aname,String aquote) {
		int update=this.jdbcTemplate.update("update Allien set aquote=? where aname=?",
				new Object[] {aquote,aname});
	
		return update;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
