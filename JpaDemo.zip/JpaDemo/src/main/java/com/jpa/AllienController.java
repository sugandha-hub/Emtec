package com.jpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AllienController {
	
	@Autowired
	AllienRepo repo;
	
	@RequestMapping("/")
	public String allien() {
		
		return "home.jsp";
		
	}
	
	@RequestMapping("/addAllien")
	public String addAllien(Allien allien) {
		repo.save(allien);
		return "home.jsp";
	}
	



}
