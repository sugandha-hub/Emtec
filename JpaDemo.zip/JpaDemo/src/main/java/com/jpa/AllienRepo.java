package com.jpa;

import org.springframework.data.repository.CrudRepository;

public interface AllienRepo extends CrudRepository<Allien, Integer>{

}
