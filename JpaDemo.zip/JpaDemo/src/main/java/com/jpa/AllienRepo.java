package com.jpa;

import org.springframework.data.repository.CrudRepository;

import antlr.collections.List;

public interface AllienRepo extends CrudRepository<Allien, Integer>{
	
	List findByAidGreaterThan(int aid);
	
}