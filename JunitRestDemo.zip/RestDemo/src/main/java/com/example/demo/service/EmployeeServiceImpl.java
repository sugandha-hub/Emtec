package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.handler.StringValueOnlyException;
import com.example.demo.repo.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepo repo;
	
	
	public List<Employee> getEmployees() {
		return repo.findAll();
	}

	public Employee getEmployeeById(int id) {
		return repo.findById(id).get();
	}

	public Employee insertEmployee(Employee employee) throws StringValueOnlyException {

		if (employee.getName().matches("[a-zA-Z]+") && employee.getTech().matches("[a-zA-Z]+")
				&& employee.getAddress().matches("[a-zA-Z]+")) {
			return repo.save(employee);
		} else {
			throw new StringValueOnlyException("Name/Tech/Address should be string");
		}

	}

	public String deleteEmployee(int id) {
		//if (repo.findById(id).isPresent()) {
			Employee emp = repo.getOne(id);
			repo.delete(emp);
			return "deleted";
//		} else {
//			return null;
//		}
	}

	public Employee updateEmployee(Employee employee) throws StringValueOnlyException {
		if (employee.getName().matches("[a-zA-Z]+") && employee.getTech().matches("[a-zA-Z]+")
				&& employee.getAddress().matches("[a-zA-Z]+")) {
			return repo.save(employee);
		} else {
			throw new StringValueOnlyException("Name/Tech/Address should be string");
		}

	}

	public List<Employee> getEmployeesByName(String name) {
		return repo.findByName(name);
	}

	public List<Employee> getEmployeesByTech(String tech) {
		return repo.findByTech(tech);
	}

	public List<String> getEmployeeNames() {
		return repo.getEmployeeNames();

	}

	public List<String> getEmployeeIdAndName() {
		return repo.getEmployeeIdAndName();

	}

	public Integer updateEmployeesByName(String name, String tech, String address) {

		repo.updateEmployeesByName(name, tech, address);
		return 1;
	}

	public Integer dropTable() {
		repo.dropTable();
		return 1;
	}

	public Integer alterTable() {
		repo.alterTable();
		return 1;
	}

	public Integer renameTable() {
		repo.renameTable();
		return 1;
	}

	public Integer createTable() {
		repo.createTable();
		return 1;
	}

}
