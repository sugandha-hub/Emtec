package com.example.demo.controllertests;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.demo.controller.EmployeeController;
import com.example.demo.entity.Employee;
import com.example.demo.handler.StringValueOnlyException;
import com.example.demo.repo.EmployeeRepo;
import com.example.demo.service.EmployeeServiceImpl;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SpringExtension.class)
public class ControllerTests {
	@MockBean
	private EmployeeServiceImpl service;

	@MockBean
	private EmployeeRepo repo;

	@InjectMocks
	private EmployeeController controller;

	@Test
	public void checkGetData() {

		// given
		Employee emp = new Employee("sugandha", "java", "wai");
		repo.save(emp);

		Employee emp2 = new Employee("komal", "react", "karad");
		repo.save(emp2);

		// when
		Mockito.when(service.getEmployees()).thenReturn(List.of(emp));
		ResponseEntity<List<Employee>> data = controller.get();

		// then
		assertThat(data.getStatusCode().OK);
	}

	@Test
	public void checkGetDataNotFound() {

		// given
		List<Employee> emp = new ArrayList();

		// when
		Mockito.when(service.getEmployees()).thenReturn(emp);
		ResponseEntity<List<Employee>> data = controller.get();

		// then
		assertThat(data.getStatusCode().NOT_FOUND);
	}

	@Test
	public void checkGetDataById() {

		// given
		Employee emp = new Employee("sugandha", "java", "wai");
		repo.save(emp);

		// when
		int id = emp.getId();
		Mockito.when(service.getEmployeeById(id)).thenReturn(emp);
		ResponseEntity<Employee> data = controller.getById(id);

		// then
		assertThat(data.getStatusCode().OK);
	}

	@Test
	public void checkInsertData() throws StringValueOnlyException {

		// given
		Employee emp = new Employee("sugandha", "java", "wai");

		// when
		Mockito.when(service.insertEmployee(emp)).thenReturn(emp);
		ResponseEntity<Employee> data = controller.post(emp);

		// then
		assertThat(data.getStatusCode().CREATED);
	}

	@Test
	public void checkDeleteData() {

		// given
		Employee emp = new Employee("sugandha", "java", "wai");
		repo.save(emp);

		// when
		int id = emp.getId();
		Mockito.when(service.deleteEmployee(id)).thenReturn("deleted");
		ResponseEntity<String> data = controller.delete(id);

		// then
		assertThat(data.getStatusCode().OK);
	}

	@Test
	public void checkDeleteDataNotFound() {
		// given
		Employee emp = new Employee("sugandha", "java", "wai");
		repo.save(emp);
		// when
		int id = 1000;
		Mockito.when(service.deleteEmployee(id)).thenReturn(null);
		ResponseEntity<String> data = controller.delete(id);

		// then
		assertThat(data.getStatusCode().NOT_FOUND);
	}

	@Test
	public void checkUpdateData() throws StringValueOnlyException {

		// given
		Employee emp = new Employee("sugandha", "java", "wai");

		// when
		Mockito.when(service.updateEmployee(emp)).thenReturn(emp);
		ResponseEntity<Employee> data = controller.put(emp);

		// then
		assertThat(data.getStatusCode().OK);
	}

	@Test
	public void checkGetDataByName() {

		// given
		Employee emp = new Employee("sugandha", "java", "wai");
		repo.save(emp);

		// when
		String name = emp.getName();
		Mockito.when(service.getEmployeesByName(name)).thenReturn(List.of(emp));
		ResponseEntity<List<Employee>> data = controller.getByName(name);

		// then
		assertThat(data.getStatusCode().OK);
	}

	@Test
	public void checkGetDataByNameNotFound() {

		// given
		List<Employee> emp = new ArrayList();

		// when
		String name = "xyz";
		Mockito.when(service.getEmployeesByName(name)).thenReturn(emp);
		ResponseEntity<List<Employee>> data = controller.getByName(name);

		// then
		assertThat(data.getStatusCode().NOT_FOUND);
	}

	@Test
	public void checkGetDataByTech() {

		// given
		Employee emp = new Employee("sugandha", "java", "wai");
		repo.save(emp);

		// when
		String tech = emp.getTech();
		Mockito.when(service.getEmployeesByTech(tech)).thenReturn(List.of(emp));
		ResponseEntity<List<Employee>> data = controller.getByTech(tech);

		// then
		assertThat(data.getStatusCode().OK);
	}

	@Test
	public void checkGetDataByTechNotFound() {

		// given
		List<Employee> emp = new ArrayList();

		// when
		String tech = "xyz";
		Mockito.when(service.getEmployeesByTech(tech)).thenReturn(emp);
		ResponseEntity<List<Employee>> data = controller.getByTech(tech);

		// then
		assertThat(data.getStatusCode().NOT_FOUND);
	}

	@Test
	public void checkGetDataNames() {

		// given
		Employee emp = new Employee("sugandha", "java", "wai");
		repo.save(emp);

		// when
		String names = emp.getName();
		Mockito.when(service.getEmployeeNames()).thenReturn(List.of(names));
		ResponseEntity<List<String>> data = controller.getOnlyNames();

		// then
		assertThat(data.getStatusCode().OK);
	}

	@Test
	public void checkGetIdDataIdAndName() {

		// given
		Employee emp = new Employee("sugandha", "java", "wai");
		repo.save(emp);

		// when
		String names = emp.getName();
		int id = emp.getId();
		String sid = Integer.toString(id);
		Mockito.when(service.getEmployeeIdAndName()).thenReturn(List.of(sid), List.of(names));
		ResponseEntity<List<String>> data = controller.getOnlyIdAndName();

		// then
		assertThat(data.getStatusCode().OK);
	}

	@Test
	public void checkUpdateDataByName() {

		// given
		Employee emp = new Employee("sugandha", "java", "wai");
		repo.save(emp);

		// when
		String name = emp.getName();
		Mockito.when(service.updateEmployeesByName(name, "react", "wai")).thenReturn(1);
		ResponseEntity<String> data = controller.updateByName(name, emp);

		// then
		assertThat(data.getStatusCode().OK);
	}

	@Test
	public void checkCreateTable() {
		// when
		Mockito.when(service.createTable()).thenReturn(1);
		ResponseEntity<String> data = controller.createTable();

		// then
		assertThat(data.getStatusCode().OK);
	}

	@Test
	public void checkAlterTable() {
		// when
		Mockito.when(service.alterTable()).thenReturn(1);
		ResponseEntity<String> data = controller.alterTable();

		// then
		assertThat(data.getStatusCode().OK);
	}

	@Test
	public void checkRenameTable() {
		// when
		Mockito.when(service.renameTable()).thenReturn(1);
		ResponseEntity<String> data = controller.renameTable();

		// then
		assertThat(data.getStatusCode().OK);
	}

	@Test
	public void checkDropTable() {
		// when
		Mockito.when(service.dropTable()).thenReturn(1);
		ResponseEntity<String> data = controller.dropTable();

		// then
		assertThat(data.getStatusCode().OK);
	}

}
