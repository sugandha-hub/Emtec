package com.example.demo.entitytests;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.entity.Employee;

public class EntityTests {
	@Autowired

	int id;
	String name, tech, address;
	private Employee emp = new Employee(name, tech, address);

	@Test
	public void checkSetId() {
		emp.setId(10);

		assertTrue(true);
	}

	@Test
	public void checkSetName() {
		emp.setName("sugandha");

		assertTrue(true);
	}

	@Test
	public void checkSetTech() {
		emp.setTech("java");

		assertTrue(true);
	}

	@Test
	public void checkSetAddress() {
		emp.setAddress("wai");

		assertTrue(true);
	}

}
