package com.example.demo.handlertests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.demo.entity.Employee;
import com.example.demo.handler.Handler;
import com.example.demo.handler.StringValueOnlyException;
import com.example.demo.repo.EmployeeRepo;
import com.example.demo.service.EmployeeService;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SpringExtension.class)
public class HandlerTests {

	@MockBean
	private EmployeeRepo repo;

	@MockBean
	EmployeeService service;

	@InjectMocks
	private Handler handler;

	@Test
	public void checkNoSuchElementException() {

		// when
		NoSuchElementException exception = assertThrows(NoSuchElementException.class, () -> {
			repo.findById(12).get();
		});

		// then
		assertEquals("No value present", exception.getMessage());
	}

	@Test
	@Disabled
	public void checkStringValueOnlyException() {
		// given
		Employee emp = new Employee("sugandha1", "java", "wai");

		// when
		StringValueOnlyException exception = assertThrows(StringValueOnlyException.class, () -> {
			service.insertEmployee(emp);

		});

		// then
		assertEquals("Name/Tech/Address should be string", exception.getMessage());

	}

}
