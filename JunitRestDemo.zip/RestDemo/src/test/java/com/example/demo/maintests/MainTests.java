package com.example.demo.maintests;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.RestDemoApplication;

public class MainTests {
	@Autowired
	RestDemoApplication MyApplication;

	@Test
	public void checkmain() {
		MyApplication.main(new String[] {});
	}

}
