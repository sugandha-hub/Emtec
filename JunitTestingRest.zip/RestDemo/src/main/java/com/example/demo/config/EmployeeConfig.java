package com.example.demo.config;

import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EmployeeConfig {

	@Bean
	public static javax.sql.DataSource source() {
		DataSourceBuilder<?> dsb = DataSourceBuilder.create();
		dsb.driverClassName("com.mysql.cj.jdbc.Driver");

		dsb.url("jdbc:mysql://localhost:3307/rest");

		dsb.username("root");
		dsb.password("");
		return dsb.build();

	}

}
