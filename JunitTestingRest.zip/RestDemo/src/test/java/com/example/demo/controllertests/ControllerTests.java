package com.example.demo.controllertests;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.queryParam;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;import org.apache.catalina.filters.CsrfPreventionFilter;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.method.annotation.RequestPartMethodArgumentResolver;

import com.example.demo.controller.EmployeeController;
import com.example.demo.entity.Employee;
import com.example.demo.repo.EmployeeRepo;
import com.example.demo.service.EmployeeService;
import com.example.demo.service.EmployeeServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(EmployeeController.class)
public class ControllerTests {
	
	@Autowired 
	private MockMvc mockMvc;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@MockBean
	private EmployeeServiceImpl service;
	
	@MockBean
	private EmployeeRepo repo;
	
	@Test
	public void checkGetData() throws JsonProcessingException, Exception {
		
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		
		Employee emp2=new Employee("komal","react","karad");
		repo.save(emp2);
		
		//when
		Mockito.when(repo.findAll()).thenReturn(List.of(emp,emp2));
		

		
		mockMvc.perform(get("/employees"));
	}
	
	@Test
	@Disabled
	public void checkGetDataById() throws JsonProcessingException, Exception {
		
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		
		//when
		Integer id=emp.getId();
		Mockito.when(repo.findById(id).get()).thenReturn(emp);
		
		mockMvc.perform(get("/employees"));
	
	}
	
	@Test
	public void checkInsertData() throws JsonProcessingException, Exception {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		
		//when
		Mockito.when(repo.save(emp)).thenReturn(emp);
		
		//then
		mockMvc.perform(post("/employees"));	
		
	}
	
	@Test
	public void checkDeleteData() throws JsonProcessingException, Exception {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		
		//when
		int id=emp.getId();
		Mockito.when(repo.getOne(id)).thenReturn(emp);
		Mockito.doNothing().when(repo).delete(emp);
		
		//then
		mockMvc.perform(delete("/employees/{id}").requestAttr("id", id));
		
	}


}
