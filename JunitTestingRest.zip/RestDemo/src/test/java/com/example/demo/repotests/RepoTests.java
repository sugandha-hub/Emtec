package com.example.demo.repotests;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.HttpStatus;
import org.springframework.test.annotation.Rollback;

import com.example.demo.entity.Employee;
import com.example.demo.repo.EmployeeRepo;


@DataJpaTest

public class RepoTests {
	
	@Autowired
	private EmployeeRepo repo;
	
	
	@Test
	public void checkGetData() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		

		//when
		List<Employee> data=repo.findAll();
		
		//then
		assertThat(data).contains(emp);
	}
	
	@Test 
	public void checkGetDataById() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
	
		//when
		int id=emp.getId();
		Employee data=repo.findById(id).get();
		
 		
		//then
		assertThat(data).isEqualTo(emp);
	}
	
	@Test 
	public void checkInsertData() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
	
		//when
		Employee data=repo.save(emp);
		
 		
		//then
		assertThat(data).hasFieldOrPropertyWithValue("name", "sugandha");
	}
	
	@Test 
	public void checkDeleteData() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
	    repo.save(emp);
	
		//when
	    Integer id=emp.getId();
		Employee data=repo.getOne(id);
		repo.delete(data);
		
 		
		//then
		assertThat(data).isEqualTo(emp);
	}
	
	@Test 
	public void checkUpdateData() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
	
		//when
		Employee data=repo.save(emp);
		
 		
		//then
		assertThat(data).hasFieldOrPropertyWithValue("name", "sugandha");
	}
	
	@Test
	public void checkGetDataByName() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		
		//when
		String name=emp.getName();
		List<Employee> data=repo.findByName(name);
		
		//then
		assertThat(data).contains(emp);
	}
	
	@Test
	public void checkGetDataByTech() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		
		//when
		String tech=emp.getTech();
		List<Employee> data=repo.findByTech(tech);
		
		//then
		assertThat(data).contains(emp);
	}
	
	
	@Test
	public void checkGetDataNames() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		Employee emp2=new Employee("komal","react","karad");
		repo.save(emp2);
		
		//when
		List<String> data=repo.getEmployeeNames();
		
		//then
		assertThat(data).contains("sugandha","komal");
	}
	
	@Test
	public void checkGetDataIdAndName() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		Employee emp2=new Employee("komal","react","karad");
		repo.save(emp2);
		
		//when
		List<String> data=repo.getEmployeeIdAndName();
		
		//then
		assertThat(data).contains("3,sugandha","4,komal");
	}
	
	
	@Test
	public void checkUpdateDataByName() {
		//given
		Employee emp=new Employee("tina","java","wai");
		repo.save(emp);
		
		//when
		String name=emp.getName();
		Integer data=repo.updateEmployeesByName(name, "spring boot","wai");
		
		
		//then
		assertEquals(data, 1);	
	}
	
	
	
	
	
	
	

	
	
	
	

}













