package com.example.demo.servicetests;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.demo.entity.Employee;
import com.example.demo.handler.StringValueOnlyException;
import com.example.demo.repo.EmployeeRepo;
import com.example.demo.service.EmployeeService;
import com.example.demo.service.EmployeeServiceImpl;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SpringExtension.class)
public class ServiceTests {
	
	@MockBean
	private EmployeeRepo repo;
	
	@InjectMocks
	private EmployeeServiceImpl service;
	
	@Test
	public void checkGetData() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		
		//when
		Mockito.when(repo.findAll()).thenReturn(List.of(emp));
		List<Employee> data=service.getEmployees();
		
		//then
		assertThat(data).isNotEmpty();
	}
	
	@Test

	public void checkGetDataById(){
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		
		//when
		int id=emp.getId();
		Mockito.when(repo.findById(id).get()).thenReturn(emp);
		Employee data=service.getEmployeeById(id);
		
		//then
		assertThat(data).isEqualTo(emp);
	}
	
	@Test
	public void checkInsertData() throws StringValueOnlyException {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		
		//when
		Mockito.when(repo.save(emp)).thenReturn(emp);
		Employee data=service.insertEmployee(emp);
		
		
		//then
		assertThat(data).isEqualTo(emp);
	}
	
	@Test
	public void checkDeleteData() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);

		
		//when
		int id=emp.getId();
		Mockito.when(repo.getOne(id)).thenReturn(emp);
		Mockito.doNothing().when(repo).delete(emp);
		
		String data=service.deleteEmployee(id);
		
		//then
		assertEquals(data, "deleted");
	
	}
	
	@Test
	public void checkUpdateData() throws StringValueOnlyException {
		//given
				Employee emp=new Employee("sugandha","java","wai");
				
				//when
				Mockito.when(repo.save(emp)).thenReturn(emp);
				Employee data=service.updateEmployee(emp);
;				
				
				//then
				assertThat(data).isEqualTo(emp);
		
	}
	
	@Test
	public void checkGetDataByName() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		
		//when
		String name=emp.getName();
		Mockito.when(repo.findByName(name)).thenReturn(List.of(emp));
		List<Employee> data=service.getEmployeesByName(name);
		
		//then
		assertThat(data).contains(emp);
	}
	
	
	@Test
	public void checkGetDataByTech() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		
		//when
		String tech=emp.getTech();
		Mockito.when(repo.findByName(tech)).thenReturn(List.of(emp));
		List<Employee> data=service.getEmployeesByName(tech);
		
		//then
		assertThat(data).contains(emp);
	}
	
	@Test
	public void checkGetDataNames() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		
		//when
		String name=emp.getName();
		Mockito.when(repo.getEmployeeNames()).thenReturn(List.of(name));
		List<String> data=service.getEmployeeNames();
		
		
		//then
		assertThat(data).contains("sugandha");
	}
	
	@Test
	public void checkGetDataIdAndName() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		
		//when
		String name=emp.getName();
		int i=emp.getId();
		String id=Integer.toString(i);
		List<String> list=new ArrayList();
		list.add(id);
		list.add(name);

		Mockito.when(repo.getEmployeeIdAndName()).thenReturn(list);
		List<String> data=service.getEmployeeIdAndName();
		
		
		//then
		assertThat(data).contains("0","sugandha");
	}
	
	@Test
	public void checkUpdateDataByName() {
		//given
		Employee emp=new Employee("sugandha","java","wai");
		repo.save(emp);
		
		//when
		String name=emp.getName();
		Mockito.when(repo.updateEmployeesByName(name, "react", "karad")).thenReturn(0);
		Integer data=service.updateEmployeesByName(name,"react","karad");
		
		//then
		assertEquals(data, 1);
	}
	
	@Test
	public void checkCreateTable() {
		//when
		Mockito.when(repo.createTable()).thenReturn(0);
		Integer data=service.createTable();
		
		//then
		assertEquals(data, 1);
	}
	
	@Test
	public void checkAlterTable() {
		//when
		Mockito.when(repo.alterTable()).thenReturn(0);
		Integer data=service.alterTable();
		
		//then
		assertEquals(data, 1);
	}
	
	@Test
	public void checkRenameTable() {
		//when
		Mockito.when(repo.renameTable()).thenReturn(0);
		Integer data=service.renameTable();
		
		//then
		assertEquals(data, 1);
	}
	
	@Test
	public void checkDropTable() {
		//when
		Mockito.when(repo.dropTable()).thenReturn(0);
		Integer data=service.dropTable();
		
		//then
		assertEquals(data, 1);
	}
	
	
	
	
	
	
	
	
	


}













