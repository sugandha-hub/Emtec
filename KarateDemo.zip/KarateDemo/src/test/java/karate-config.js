function function1(){

	var data={
		name: "sugandha"
	}
	return data;
}
