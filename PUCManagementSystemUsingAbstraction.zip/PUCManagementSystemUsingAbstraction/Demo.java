import javax.swing.JFrame;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.*;
import java.net.*;

class Demo {
    public static void main(String args[]) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        Date date1 = sdf.parse("12-05-2022");
        Date date2 = sdf.parse("14-05-2022");

        Users user1 = new Users(7028351864L, date1, "Sugandha Dhanawade", "wai");
        Users user2 = new Users(7028351864L, date2, "Rutuja Dhanawade", "pune");
        Users user3 = new Users(9168926907L, date2, "Priyanka Deshpande", "islampur");
        // Users user2=new Users(9168926907L,17052022,"Rutuja Dhanawade","pune");
        user1.userdata();
        user2.userdata();
        user3.userdata();

    }
}

// abstract class
abstract class AbstractClass {
    abstract void userdata() throws ParseException;
}

class Users extends AbstractClass {

    long mobile;
    Date expirationDate;
    String name, address;

    Users(long mobile, Date expirationDate, String name, String address) {
        this.mobile = mobile;
        this.expirationDate = expirationDate;
        this.name = name;
        this.address = address;
        // System.out.println(mobile+" "+expirationDate+" "+name+" "+address);

    }

    void userdata() throws ParseException {

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        Date date = sdf.parse("13-05-2022");

        if (expirationDate.after(date)) {

            System.out.println(mobile + "\n" + expirationDate + " " + name + " " + address);
            try {
                // Construct data
                String apiKey = "apikey=" + "NWE0ZTYxNDI2MTc5NTE1NTU1NmM1ODc4NGE2MzY2NTk=";
                String message = "&message=" + "Hey! You need to renew your certificate, your expiration date is "+expirationDate;
                String sender = "&sender=" + "Sugandha";
                String numbers = "&numbers=" + mobile;
     
                // Send data
                HttpURLConnection conn = (HttpURLConnection) new URL("https://api.textlocal.in/send/?").openConnection();
                String data = apiKey + numbers + message + sender;
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Length", Integer.toString(data.length()));
                conn.getOutputStream().write(data.getBytes("UTF-8"));
                 
                BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuffer stringBuffer = new StringBuffer();
                String line;
                while ((line = rd.readLine()) != null) {
                    stringBuffer.append(line).append("\n");
                }
                System.out.println(stringBuffer.toString());
                rd.close();
     
     
            } catch (Exception e) {
               e.printStackTrace();
            }
           

    }
}

}