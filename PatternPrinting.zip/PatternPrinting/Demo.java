import java.util.*;

class Demo {

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        while(true){
            System.out.println("Welcome to the pattern printing of triangles!");
        System.out.println("Choose which pattern you wanna display:");
        System.out.println(
                "1. Simple Triangle \n2. Left Triangle \n3. Right Triangle \n4. Left Down Triangle \n5. Right Down Triangle \n6. Simple Down Triangle");
        int choice = sc.nextInt();
       
            switch (choice) {
                case 1:
                    System.out.println("This is Simple Triangle pattern :)");
                    for (int i = 1; i <= 4; i++) {
                        for (int k = 4; k > i; k--) {

                            System.out.print(" ");

                        }
                        for (int j = 1; j <= i; j++) {
                            System.out.print(" * ");
                        }

                        System.out.print("\n");
                    }
                    break;

                case 2:
                    System.out.println("This is Left Triangle pattern :)");
                    for (int i = 1; i <= 4; i++) {
                        for (int k = 1; k <= i; k++) {
                            System.out.print(" * ");

                        }

                        System.out.print("\n");
                    }
                    break;

                case 3:
                    System.out.println("This is Right Triangle pattern :)");
                    for (int i = 1; i <= 4; i++) {
                        for (int k = 4; k > i; k--) {

                            System.out.print(" ");

                        }
                        for (int j = 1; j <= i; j++) {
                            System.out.print("*");
                        }

                        System.out.print("\n");
                    }

                    break;

                case 4:
                    System.out.println("This is Left Down Triangle pattern :)");
                    for (int i = 4; i >= 1; i--) {
                        for (int k = i; k >= 1; k--) {
                            System.out.print(" * ");

                        }

                        System.out.print("\n");
                    }

                    break;

                case 5:
                    System.out.println("This is Right Down Triangle pattern :)");
                    for (int i = 4; i >= 1; i--) {
                        for (int k = i; k < 4; k++) {

                            System.out.print(" ");

                        }
                        for (int j = i; j >= 1; j--) {
                            System.out.print("*");
                        }

                        System.out.print("\n");
                    }

                    break;

                case 6:
                    System.out.println("This is Simple Down Triangle pattern :)");
                    for (int i = 4; i >= 1; i--) {
                        for (int k = i; k < 4; k++) {

                            System.out.print(" ");

                        }
                        for (int j = i; j >= 1; j--) {
                            System.out.print(" * ");
                        }

                        System.out.print("\n");
                    }

                    break;

                default:
                    System.out.println("Please enter the correct choice");

            }


        }
        

    }
}