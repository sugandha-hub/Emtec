package com.example.demo.main;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity

public class Employee {

	// accessing application properties data

	@Id
	@Column(name = "id")
	private int eid;

	@NotBlank(message = "name cannot be null/empty/blank")
	@Size(min = 2, message = "Your name should have atleast 2 characters")
	@Column(name = "name")
	private String ename;

	@Column(name = "tech")
	@NotBlank(message = "tech cannot be null/empty/blank")
	@Size(min = 2, message = "Your tech should have atleast 2 characters")
	private String etech;

	@Column(name = "address")
	@NotBlank(message = "address cannot be null/empty/blank")
	@Size(min = 2, message = "Your address should have atleast 2 characters")
	private String eaddress;

	public int getEid() {
		return eid;
	}

	public void setEid(@NotNull int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(@NotNull String ename) {
		this.ename = ename;
	}

	public String getEtech() {
		return etech;
	}

	public void setEtech(@NotNull String etech) {
		this.etech = etech;
	}

	public String getEaddress() {
		return eaddress;
	}

	public void setEaddress(@NotNull String eaddress) {
		this.eaddress = eaddress;
	}

//	@Value("${name}")
//
//	private String appname;
//
//	public void showApplicationPropertiesData() {
//		System.out.println("Name=" + appname);
//
//	}

}
