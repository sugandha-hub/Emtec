package com.example.demo.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.main.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, Integer> {

	List<Employee> findByEname(String name);

	List<Employee> findByEtech(String tech);
	 
	@Query(value = "SELECT name from Employee", nativeQuery = true)
	List<String> getEmployeeNames();

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "UPDATE employee set tech=:t,address=:a where name=:n", nativeQuery = true)
	Integer updateEmployeesByName(@Param("n") String name, @Param("t") String tech, @Param("a") String address);

	@Query(value = "SELECT id,name from Employee", nativeQuery = true)
	List<String> getEmployeeIdAndName();

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "DROP table emp", nativeQuery = true)
	Integer dropTable();

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "ALTER TABLE emp ADD hobby varchar(40)", nativeQuery = true)
	Integer alterTable();

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "ALTER TABLE emp rename to student", nativeQuery = true)
	Integer renameTable();

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "CREATE table if not exists emp(name varchar(50))", nativeQuery = true)
	Integer createTable();

}
