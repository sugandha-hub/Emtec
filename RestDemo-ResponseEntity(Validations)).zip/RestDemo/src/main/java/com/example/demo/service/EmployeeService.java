package com.example.demo.service;

import java.util.List;

import com.example.demo.main.Employee;

public interface EmployeeService {

	public List<Employee> getEmployees();

	public Employee getEmployeeById(int id);

	public Employee insertEmployee(Employee employee);

	public String deleteEmployee(int id);

	public Employee updateEmployee(Employee employee);

	public List<Employee> getEmployeesByName(String name);

	public List<Employee> getEmployeesByTech(String tech);

	public List<String> getEmployeeNames();

	public List<String> getEmployeeIdAndName();

	public Integer updateEmployeesByName(String name, String tech, String address);

	public Integer dropTable();

	public Integer alterTable();

	public Integer renameTable();

	public Integer createTable();

}
