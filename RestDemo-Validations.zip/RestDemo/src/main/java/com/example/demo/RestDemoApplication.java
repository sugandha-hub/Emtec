package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.main.Employee;

@SpringBootApplication()
public class RestDemoApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(RestDemoApplication.class, args);
		Employee a = context.getBean(Employee.class);

		// showing application properties data
//		a.showApplicationPropertiesData();
//		

	}

}
