package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.main.Employee;
import com.example.demo.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeService as;

	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> get() {

		List<Employee> list = as.getEmployees();
		if (list.size() <= 0) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();

		}
		return ResponseEntity.ok(list);

	}

	@GetMapping("/employees/{id}")
	public ResponseEntity<Employee> getById(@PathVariable("id") int id) {
		Employee emp = as.getEmployeeById(id);

		return ResponseEntity.ok(emp);
	}

	@PostMapping("/employees")

	public ResponseEntity<String> post(@Valid @RequestBody Employee employee) {

		Employee emp = as.insertEmployee(employee);

		return ResponseEntity.status(HttpStatus.CREATED).body("Inserted record successfully");

	}

	@DeleteMapping("/employees/{id}")
	public ResponseEntity<String> delete(@PathVariable("id") int id) {

		as.deleteEmployee(id);

		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();

	}

	@PutMapping("/employees")
	public ResponseEntity<Employee> put(@Valid @RequestBody Employee employee) {
		Employee emp = as.updateEmployee(employee);
		return ResponseEntity.ok(emp);

	}

	@GetMapping("/employees/name={name}")
	public ResponseEntity<List<Employee>> getByName(@PathVariable("name") String name) {
		List<Employee> list = as.getEmployeesByName(name);
		if (list.size() <= 0) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		} else {
			return ResponseEntity.ok(list);
		}

	}

	@GetMapping("/employees/tech={tech}")
	public ResponseEntity<List<Employee>> getByTech(@PathVariable("tech") String tech) {
		List<Employee> list = as.getEmployeesByTech(tech);

		if (list.size() <= 0) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		} else {
			return ResponseEntity.ok(list);
		}

	}

	@GetMapping("/employees/get/id/name")

	public ResponseEntity<List<String>> getOnlyIdAndName() {

		List<String> list = as.getEmployeeIdAndName();

		if (list.size() <= 0) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		} else {
			return ResponseEntity.ok(list);
		}

	}

	@GetMapping("/employees/get/name")

	public ResponseEntity<List<String>> getOnlyNames() {

		List<String> list = as.getEmployeeNames();

		if (list.size() <= 0) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		} else {
			return ResponseEntity.ok(list);
		}

	}

	@PutMapping("/employees/{name}")
	public ResponseEntity<String> updateByName(@PathVariable("name") String name,
			@Valid @RequestBody Employee employee) {
		String tech = employee.getEtech();
		String address = employee.getEaddress();
		as.updateEmployeesByName(name, tech, address);

		return ResponseEntity.status(HttpStatus.OK).build();

	}

	@DeleteMapping("/employees")
	public ResponseEntity<Integer> dropTable() {
		as.dropTable();
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

	@PostMapping("/employees/alter")
	public ResponseEntity<Integer> alterTable() {
		as.alterTable();
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@PutMapping("/employees/rename")
	public ResponseEntity<Integer> renameTable() {
		as.renameTable();
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@PostMapping("/employees/create")
	public ResponseEntity<Integer> createTable() {
		as.createTable();
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

}
