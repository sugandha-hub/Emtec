package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Allien {
	
	@Id
	private int aid;
	private String aname;
	private String atech;
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getAname() {
		return aname;
	}
	@Override
	public String toString() {
		return "Allien [aid=" + aid + ", aname=" + aname + ", atech=" + atech + "]";
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public String getAtech() {
		return atech;
	}
	public void setAtech(String atech) {
		this.atech = atech;
	}

}
