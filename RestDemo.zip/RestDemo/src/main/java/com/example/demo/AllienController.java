package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AllienController {
	
	@Autowired
	AllienRepo repo;
	
	@GetMapping("/alliens")
	public List<Allien> getAlliens() {
		return repo.findAll();
	}
	
	@RequestMapping("/alliens/{aid}")
	public Optional<Allien> getAlliens(@PathVariable("aid") int aid) {
		return repo.findById(aid);
	}
	
	@PostMapping("/alliens")
	public Allien postAlliens(@RequestBody Allien allien) {
		 repo.save(allien);
		 return allien;
	}
	
	@SuppressWarnings("deprecation")
	@DeleteMapping("/alliens/{aid}")
	public String deleteAlliens(@PathVariable int aid) {
		Allien a=repo.getOne(aid);
		repo.delete(a);
		return "deleted";
	}
	
	
	@PutMapping("/alliens")
	public Allien updateAlliens(@RequestBody Allien allien) {
		 repo.save(allien);
		 return allien;
	}


}
















