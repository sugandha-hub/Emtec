package com.example.demo;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.example.demo.main.Allien;


@SpringBootApplication() 
public class RestDemoApplication {
	


	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(RestDemoApplication.class, args);
		Allien a=context.getBean(Allien.class);
		
		//showing application properties data
		a.showApplicationPropertiesData();
		
		
	
	}

}
