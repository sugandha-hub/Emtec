package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.main.Allien;
import com.example.demo.main.AllienRepo;
import com.example.demo.service.AllienService;

@RestController
public class AllienController {
	
	@Autowired
	AllienService as;
	
	@GetMapping("/alliens")
	public List<Allien> get() {
	return as.getAlliens();
	}
	
	
	@GetMapping("/alliens/{aid}")
	public Optional<Allien> getById(@PathVariable("aid") int aid) {
		return as.getAlliensById(aid);
	}
	
	
	@PostMapping("/alliens")
	public Allien post(@RequestBody Allien allien) {
		return as.postAlliens(allien);
		
	}
	
	
	
	@DeleteMapping("/alliens/{aid}")
	public String delete(@PathVariable int aid) {
		return as.deleteAlliens(aid);
		
	}
	
	
	
	@PutMapping("/alliens")
	public Allien put(@RequestBody Allien allien) {
		return as.updateAlliens(allien);
		
	}

	
	//custom functions here
	
	@GetMapping("/alliens/name={aname}")
	public Optional<Allien> getByName(@PathVariable("aname") String aname) {
		return as.getAlliensByName(aname);
	}

	
	
	@GetMapping("/alliens/tech:{atech}")
	public Optional<Allien> getByTech(@PathVariable("atech") String atech) {
		return as.getAlliensByTech(atech);
		
	}
	
	

}
















