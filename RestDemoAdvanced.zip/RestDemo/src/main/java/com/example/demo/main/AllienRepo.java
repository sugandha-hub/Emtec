package com.example.demo.main;

import java.util.List;
import java.util.Optional;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;


public interface AllienRepo extends JpaRepository<Allien,Integer>{
	
	Optional<Allien> findByaname(String aname);
	Optional<Allien> findByatech(String atech);
}
