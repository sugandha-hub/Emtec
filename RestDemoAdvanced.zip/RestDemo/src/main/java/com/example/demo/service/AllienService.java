package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.main.Allien;
import com.example.demo.main.AllienRepo;

@Service
public class AllienService {
	
	@Autowired
	AllienRepo repo;
	
	
	public List<Allien> getAlliens() {
		return repo.findAll();
	
	}
	
	public Optional<Allien> getAlliensById(@PathVariable("aid") int aid) {
		return repo.findById(aid);
	}
	
	public Allien postAlliens(@RequestBody Allien allien) {
		 repo.save(allien);
		 return allien;
	}
	
	@SuppressWarnings("deprecation")
	public String deleteAlliens(@PathVariable int aid) {
		Allien a=repo.getOne(aid);
		repo.delete(a);
		return "deleted";
	}
	
	public Allien updateAlliens(@RequestBody Allien allien) {
		 repo.save(allien);
		 return allien;
	}
	
	//custom functions here
	
	public Optional<Allien> getAlliensByName(@PathVariable("aname") String aname){
		return repo.findByaname(aname);
	}
	
	public Optional<Allien> getAlliensByTech(@PathVariable("atech") String atech){
		return repo.findByatech(atech);
	}

}
