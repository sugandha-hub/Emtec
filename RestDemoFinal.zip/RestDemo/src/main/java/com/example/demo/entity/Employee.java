package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity

public class Employee {

	// accessing application properties data

	@Id
	@Column(name = "EmployeeId")
	private int id;

	@NotBlank(message = "name cannot be null/empty/blank")
	@Size(min = 2, message = "Your name should have atleast 2 characters")
	@Column(name = "EmployeeName")
	private String name;

	@Column(name = "EmployeeTech")
	@NotBlank(message = "tech cannot be null/empty/blank")
	@Size(min = 2, message = "Your tech should have atleast 2 characters")
	private String tech;

	@Column(name = "EmployeeAddress")
	@NotBlank(message = "address cannot be null/empty/blank")
	@Size(min = 2, message = "Your address should have atleast 2 characters")
	private String address;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTech() {
		return tech;
	}

	public void setTech(String tech) {
		this.tech = tech;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
