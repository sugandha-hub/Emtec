package com.example.demo.handler;

public class StringValueOnlyException extends Exception {

	public StringValueOnlyException(String msg) {
		super(msg);
	}
}
