import java.util.*;

class HR {
    String name;
    int leaves, desig;

    HR(String name, int desig, int leaves) {
        this.name = name;
        this.desig = desig;
        this.leaves = leaves;
    }

}

class Company extends HR {
    int salary;

    Company(String name, int desig, int leaves) {
        super(name, desig, leaves);
        // System.out.println(name + " " + desig + " " + leaves);

    }

    void putdata() {
        switch (desig) {

            case 1:
                if (leaves <= 3) {
                    salary = 50000;
                } else {
                    salary = 50000 - ((leaves - 3) * 1666);
                }
                System.out.println("Your salary for the month is " + salary);

                break;

            case 2:
                if (leaves <= 3) {
                    salary = 70000;
                } else {
                    salary = 70000 - ((leaves - 3) * 2333);
                }
                System.out.println("Hey "+name+" your salary for the month is " + salary);
                break;

            case 3:
                if (leaves <= 3) {
                    salary = 90000;
                } else {
                    salary = 90000 - ((leaves - 3) * 3000);
                }
                System.out.println("Your salary for the month is " + salary);
                break;

            default:
                System.out.println("Please enter the correct designation");
                break;

        }
    }

}

// class Employee extends Company{

// }

class Demo {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);

        System.out.println("\n\n\n\nWelcome to the company's salary calculation portal");
        System.out.println("----------------------------------------------------------------------");
        System.out.println("Current salaries are");
        System.out.println("Associate Software Developer= 50K");
        System.out.println("Senior Software Developer= 70K");
        System.out.println("Technical Lead= 90K");
        System.out.println("----------------------------------------------------------------------");
        System.out.println("3 leaves for the month are allowed");
        System.out.println("----------------------------------------------------------------------");
        System.out.println("Enter your name:");
        String name = sc.nextLine();
        System.out.println(
                "Enter your designation \n1. Associate Software Developer 2. Senior Software Developer 3. Technical Lead");
        int desig = sc.nextInt();
        System.out.println("----------------------------------------------------------------------");
        System.out.println("Enter the number of leaves taken this month:");
        int leaves = sc.nextInt();
        System.out.println("----------------------------------------------------------------------");

        Company company = new Company(name, desig, leaves);
        company.putdata();

    }
}
