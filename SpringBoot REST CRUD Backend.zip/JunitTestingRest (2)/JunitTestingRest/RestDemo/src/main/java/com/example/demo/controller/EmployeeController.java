package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;
import com.example.demo.handler.StringValueOnlyException;
import com.example.demo.service.EmployeeServiceImpl;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeServiceImpl as;

	private Employee emp;
	
	@RequestMapping("/")
	public String homePage() {
		
		return "Home.jsp";
	}

	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> get() {
		List<Employee> data = as.getEmployees();
		Map<String, Employee> listToMap = data.stream().collect(Collectors.toMap(Employee::getName, emp -> emp));
		List<Employee> mapToList = listToMap.values().stream().filter(emp -> emp.getId() > 5)
				.collect(Collectors.toList());

		List msg = new ArrayList();
		msg.add("Data Not Found");
		if (data.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(msg);
		} else {

			//return ResponseEntity.status(HttpStatus.OK).body(data);
			// ResponseEntity.status(HttpStatus.OK).body(listToMap);
			return ResponseEntity.status(HttpStatus.OK).body(data);
		}
		

	}

	@GetMapping("/employees/{id}")
	public ResponseEntity<Employee> getById(@PathVariable("id") int id) {
		Employee data = as.getEmployeeById(id);
		return ResponseEntity.status(HttpStatus.OK).body(data);
	}

	@PostMapping("/employees")
	public ResponseEntity<Employee> post(@Valid @RequestBody Employee employee) throws StringValueOnlyException {
		Employee emp = as.insertEmployee(employee);
		return ResponseEntity.status(HttpStatus.CREATED).body(emp);

	}

	@DeleteMapping("/employees/{id}")
	public ResponseEntity<String> delete(@PathVariable("id") int id) {
		String data = as.deleteEmployee(id);
		if (data == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Data Not Found");
		} else {
			return ResponseEntity.status(HttpStatus.OK).body("Data Deleted");
		}
	}

	@PutMapping("/employees")
	public ResponseEntity<Employee> put(@Valid @RequestBody Employee employee) throws StringValueOnlyException {
		Employee emp = as.updateEmployee(employee);
		return ResponseEntity.status(HttpStatus.OK).body(emp);

	}

	@GetMapping("/employees/name={name}")
	public ResponseEntity<List<Employee>> getByName(@PathVariable("name") String name) {
		List<Employee> data = as.getEmployeesByName(name);
		List msg = new ArrayList();
		msg.add("Data Not Found");
		if (data.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(msg);
		} else {
			return ResponseEntity.status(HttpStatus.OK).body(data);
		}
	}

	@GetMapping("/employees/tech={tech}")
	public ResponseEntity<List<Employee>> getByTech(@PathVariable("tech") String tech) {
		List<Employee> data = as.getEmployeesByTech(tech);
		List msg = new ArrayList();
		msg.add("Data Not Found");
		if (data.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(msg);
		} else {
			return ResponseEntity.status(HttpStatus.OK).body(data);
		}
	}

	@GetMapping("/employees/get/id/name")

	public ResponseEntity<List<String>> getOnlyIdAndName() {

		List<String> list = as.getEmployeeIdAndName();
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}

	@GetMapping("/employees/get/name")

	public ResponseEntity<List<String>> getOnlyNames() {

		List<String> list = as.getEmployeeNames();
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}

	@PutMapping("/employees/{name}")
	public ResponseEntity<String> updateByName(@PathVariable("name") String name,
			@Valid @RequestBody Employee employee) {
		String tech = employee.getTech();
		String address = employee.getAddress();
		as.updateEmployeesByName(name, tech, address);

		return ResponseEntity.status(HttpStatus.OK).body("Data Updated");
	}

	@DeleteMapping("/employees")
	public ResponseEntity<String> dropTable() {
		as.dropTable();
		return ResponseEntity.status(HttpStatus.OK).body("Table Dropped");
	}

	@PostMapping("/employees/alter")
	public ResponseEntity<String> alterTable() {
		as.alterTable();
		return ResponseEntity.status(HttpStatus.CREATED).body("Table Altered");
	}

	@PutMapping("/employees/rename")
	public ResponseEntity<String> renameTable() {
		as.renameTable();
		return ResponseEntity.status(HttpStatus.OK).body("Table Renamed");
	}

	@PostMapping("/employees/create")
	public ResponseEntity<String> createTable() {
		as.createTable();
		return ResponseEntity.status(HttpStatus.CREATED).body("Table Created");
	}

}
