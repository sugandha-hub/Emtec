package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
public class Employee {

	// accessing application properties data

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@Column(name = "EmployeeId")
	private int id;

	@NotBlank(message = "name cannot be null/empty/blank")
	@Size(min = 2, message = "Your name should have atleast 2 characters")
	@Column(name = "EmployeeName")
	private String name;

	@Column(name = "EmployeeTech")
	@NotBlank(message = "tech cannot be null/empty/blank")
	@Size(min = 2, message = "Your tech should have atleast 2 characters")
	private String tech;

	@Column(name = "EmployeeAddress")
	@NotBlank(message = "address cannot be null/empty/blank")
	@Size(min = 2, message = "Your address should have atleast 2 characters")
	private String address;

	public Employee(String string, String string2, String string3) {
		this.name=string;
		this.tech=string2;
        this.address=string3;
		
		// TODO Auto-generated constructor stub
	}
	public Employee() {
			
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTech() {
		return tech;
	}

	public void setTech(String tech) {
		this.tech = tech;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
