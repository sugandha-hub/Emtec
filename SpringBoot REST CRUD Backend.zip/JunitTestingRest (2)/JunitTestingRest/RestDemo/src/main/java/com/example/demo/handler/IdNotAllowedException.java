package com.example.demo.handler;

public class IdNotAllowedException extends RuntimeException{
	public IdNotAllowedException(String msg) {
		super(msg);
	}

}
