package com.example.demo.maintests;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.RestDemoApplication;

@ExtendWith(MockitoExtension.class)
public class MainTests {
	@Mock
	private RestDemoApplication MyApplication;

	@Test
	public void checkmain() {
		MyApplication.main(new String[] {});
	}

}
