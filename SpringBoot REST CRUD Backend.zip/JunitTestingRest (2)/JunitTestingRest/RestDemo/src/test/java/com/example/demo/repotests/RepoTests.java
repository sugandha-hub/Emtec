package com.example.demo.repotests;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.constraints.AssertTrue;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.demo.entity.Employee;
import com.example.demo.repo.EmployeeRepo;

@ExtendWith(MockitoExtension.class)
public class RepoTests {

	@Mock
	private EmployeeRepo repo;

	@Test
	public void checkGetData() {
		// given
		Employee emp = new Employee("sugandha", "java", "wai");

		// when
		Mockito.when(repo.findAll()).thenReturn(List.of(emp));

		// then
		assertEquals(repo.findAll(), List.of(emp));
	}

	@Test
	public void checkGetDataById() {
		// given
		Employee emp = new Employee("sugandha", "java", "wai");

		// when
		int id = emp.getId();
		Mockito.when(repo.findById(id)).thenReturn(Optional.ofNullable(emp));

		// then
		assertEquals(repo.findById(id).get(), emp);
	}

	@Test
	public void checkInsertData() {
		// given
		Employee emp = new Employee("sugandha", "java", "wai");

		// when
		Mockito.when(repo.save(emp)).thenReturn(emp);

		// then
		assertEquals(repo.save(emp), emp);
	}

	@Test
	@Disabled
	public void checkDeleteData() {
		// given
		Employee emp = new Employee("sugandha", "java", "wai");

		// when
		int id = emp.getId();
		Mockito.lenient().when(repo.getOne(id)).thenReturn(emp);
		Mockito.doNothing().when(repo).delete(emp);

		// then
		assertTrue(true);
	}

	@Test
	public void checkUpdateData() {
		// given
		Employee emp = new Employee("sugandha", "java", "wai");

		// when
		Mockito.when(repo.save(emp)).thenReturn(emp);

		// then
		assertEquals(repo.save(emp), emp);
	}

	@Test
	public void checkGetDataByName() {
		// given
		Employee emp = new Employee("sugandha", "java", "wai");

		// when
		String name = emp.getName();
		Mockito.when(repo.findByName(name)).thenReturn(List.of(emp));

		// then
		assertEquals(repo.findByName(name), List.of(emp));
	}

	@Test
	public void checkGetDataByTech() {
		// given
		Employee emp = new Employee("sugandha", "java", "wai");

		// when
		String tech = emp.getTech();
		Mockito.when(repo.findByTech(tech)).thenReturn(List.of(emp));

		// then
		assertEquals(repo.findByTech(tech), List.of(emp));
	}

	@Test
	public void checkGetDataNames() {
		// given
		Employee emp = new Employee("sugandha", "java", "wai");

		// when
		String name = emp.getName();
		Mockito.when(repo.getEmployeeNames()).thenReturn(List.of(name));

		// then
		assertEquals(repo.getEmployeeNames(), List.of(name));
	}

	@Test
	public void checkGetDataIdAndName() {
		// given
		Employee emp = new Employee("sugandha", "java", "wai");

		// when
		String name = emp.getName();
		int i = emp.getId();
		String id = Integer.toString(i);
		List<String> list = new ArrayList();
		list.add(id);
		list.add(name);

		Mockito.when(repo.getEmployeeIdAndName()).thenReturn(list);

		// then
		assertEquals(repo.getEmployeeIdAndName(), list);
	}

	@Test
	public void checkUpdateDataByName() {
		// given
		Employee emp = new Employee("tina", "java", "wai");

		// when
		String name = emp.getName();
		Mockito.when(repo.updateEmployeesByName(name, "react", "karad")).thenReturn(0);

		// then
		assertEquals(repo.updateEmployeesByName(name, "react", "karad"), 0);
	}

	@Test
	public void checkCreateTable() {
		// when
		Mockito.when(repo.createTable()).thenReturn(0);

		// then
		assertEquals(repo.createTable(), 0);

	}

	@Test
	public void checkAlterTable() {
		// when
		Mockito.when(repo.alterTable()).thenReturn(0);

		// then
		assertEquals(repo.alterTable(), 0);

	}

	@Test
	public void checkRenameTable() {
		// when
		Mockito.when(repo.renameTable()).thenReturn(0);

		// then
		assertEquals(repo.renameTable(), 0);

	}

	@Test
	public void checkDropTable() {
		// when
		Mockito.when(repo.dropTable()).thenReturn(0);

		// then
		assertEquals(repo.dropTable(), 0);

	}

}
