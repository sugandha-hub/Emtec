package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


//only one object is created
@Component

//based on how many times you call bean, that many objects will get created
@Scope(value="prototype")
public class DependencyInjectionDemo {
	
	
	//getting the object of another class in non-main class isn't possible through getBean(), here we can get that through @Autowired
	//@Autowired can get the object type
	@Autowired
	

	private DependencyInjectionDemo2 obj2;
	private int id;
	private String name;
	private String tech;
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id=id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	
	public String getTech() {
		return tech;
	}
	public void setTech(String tech) {
		this.tech=tech;
	}
	
	public void show() {
		
		
		System.out.println("show of class 1.....");
		obj2.show();
		
	}
	
	

}
