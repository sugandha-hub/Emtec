class Demo {
    public static void main(String args[]){
        // DeskPhone myPhone= new DeskPhone( "123456");
        // myPhone.powerOn();
        // myPhone.callPhone("123456");
        // myPhone.answer();

        MobilePhone myPhone= new MobilePhone("12345");
        myPhone.powerOn();
        myPhone.callPhone("12345");
        myPhone.answer();
    }
}

interface Telephone{
    void powerOn();
    void dial(String phoneNumber);
    void answer();
    boolean callPhone(String phoneNumber);
    boolean isRinging();

}

class DeskPhone implements Telephone{
    private String myNumber;
    private boolean isRinging;

    public DeskPhone(String myNumber){
        this.myNumber=myNumber;
    }

    public void powerOn(){
        System.out.println("Desk Phone is always powered");

    }
    public void dial(String phoneNumber){
        System.out.println("Now Ringing"+phoneNumber+"on deskphone");


    }


    public void answer(){
        if(isRinging){
            System.out.println("Answering the desk phone");
            isRinging=false;
        }
        else{
            System.out.println("Phone is not ringing");
        }


    }

    public boolean callPhone(String phoneNumber){
        if(phoneNumber == myNumber){
            isRinging= true;
            System.out.println("Phone ringing");
        }
        else{
            isRinging=false;
        }
        return isRinging;
    }

    @Override
    public boolean isRinging() {
        // TODO Auto-generated method stub
        return isRinging;
    }
}

class MobilePhone implements Telephone{
    private String myNumber;
    private boolean isRinging;
    private boolean isPowerOn;

    public MobilePhone(String myNumber){
        this.myNumber=myNumber;
    }

    public void powerOn(){
        isPowerOn= true;
        System.out.println("Phone powered on");

    }
    public void dial(String phoneNumber){
        System.out.println("Now Ringing"+phoneNumber+"on mobile phone");


    }


    public void answer(){
        if(isRinging && isPowerOn){
            System.out.println("Answering the mobile phone");
            isRinging=false;
        }
        else{
            System.out.println("Phone is not ringing");
        }


    }

    public boolean callPhone(String phoneNumber){
        if(phoneNumber == myNumber && isPowerOn){
            isRinging= true;
            System.out.println("Phone ringing");
        }
        else{
            System.out.println("Either wrong number entered or phone is off");
            isRinging=false;
        }
        return isRinging;
    }

    @Override
    public boolean isRinging() {
        // TODO Auto-generated method stub
        return isRinging;
    }
}