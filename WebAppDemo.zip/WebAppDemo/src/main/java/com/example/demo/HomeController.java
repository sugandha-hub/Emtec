package com.example.demo;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	@RequestMapping("/home")
	public String home(HttpServletRequest req) {
		
		//accessing parameter from request using HttpServletRequest
		String name=req.getParameter("name");
		System.out.println("Hiiiiiiii");
		
		System.out.println("Hi, "+name);

		return "home.jsp";
		
	}

}
